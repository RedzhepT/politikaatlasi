<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<div class="breadcrumbs">
    <div class="page-header d-flex align-items-center">
        <div class="container position-relative">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-6 text-center">
                    <h1><?php echo e($article->title); ?></h1>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Breadcrumb Navigation -->
<div class="breadcrumb-nav">
    <div class="container">
        <ol>
            <li><a href="<?php echo e(route('home')); ?>">Anasayfa</a></li>
            <li><a href="<?php echo e(route('articles.index')); ?>">Blog</a></li>
            <li><?php echo e($article->title); ?></li>
        </ol>
    </div>
</div>

<!-- Article Content -->
<section id="blog" class="blog">
    <div class="container" data-aos="fade-up">
        <div class="row g-5">
            <div class="col-lg-8">
                <article class="blog-details">
                    <?php if($article->image): ?>
                    <div class="post-img">
                        <img src="<?php echo e($article->image_url); ?>" alt="<?php echo e($article->title); ?>" class="img-fluid">
                    </div>
                    <?php endif; ?>

                    <h2 class="title"><?php echo e($article->title); ?></h2>

                    <div class="meta-top">
                        <ul>
                            <li class="d-flex align-items-center">
                                <i class="bi bi-person"></i>
                                <a href="#"><?php echo e($article->author_name); ?></a>
                            </li>
                            <li class="d-flex align-items-center">
                                <i class="bi bi-clock"></i>
                                <a href="#"><time datetime="<?php echo e($article->created_at); ?>"><?php echo e($article->created_at->format('d M Y')); ?></time></a>
                            </li>
                            <li class="d-flex align-items-center">
                                <i class="bi bi-eye"></i>
                                <a href="#"><?php echo e($article->views); ?> Görüntülenme</a>
                            </li>
                        </ul>
                    </div>

                    <div class="content">
                        <?php echo $article->content; ?>

                    </div>
                </article>
            </div>

            <div class="col-lg-4">
                <?php echo $__env->make('articles.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>

        <!-- Yorumlar Bölümü -->
        <div class="row g-5">
            <div class="col-lg-8">
                <div class="comments-section mt-5">
                    <h3>Yorumlar</h3>
                    
                    <?php $__empty_1 = true; $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="comment border-bottom py-3">
                            <div class="d-flex align-items-center mb-2">
                                <strong><?php echo e($comment->user->name); ?></strong>
                                <small class="text-muted ms-2"><?php echo e($comment->created_at->diffForHumans()); ?></small>
                            </div>
                            <p class="mb-0"><?php echo e($comment->content); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert alert-info">
                            Henüz yorum yapılmamış. İlk yorumu siz yapın!
                        </div>
                    <?php endif; ?>

                    <div class="comment-form mt-4">
                        <?php if(auth()->guard()->check()): ?>
                            <form action="<?php echo e(route('comments.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="article_id" value="<?php echo e($article->id); ?>">
                                <div class="mb-3">
                                    <label for="content" class="form-label">Yorumunuz</label>
                                    <textarea class="form-control <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="content" 
                                            name="content" 
                                            rows="3" 
                                            required></textarea>
                                    <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <button type="submit" class="btn btn-primary">Yorum Yap</button>
                            </form>
                        <?php else: ?>
                            <div class="alert alert-info">
                                Yorum bırakmak için <a href="<?php echo e(route('login') . '?redirect=' . request()->url()); ?>">giriş yapmalısınız</a>.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->startSection('styles'); ?>
<style>
    /* Navbar için stiller */
    .header {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 997;
        background: var(--color-primary);
    }

    /* Navbar link renkleri */
    .header a {
        color: white !important;
    }

    .header .logo h1 {
        color: white !important;
    }

    /* Hero Section için stiller */
    .breadcrumbs {
        padding: 140px 0 60px 0;
        min-height: 30vh;
        position: relative;
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        background-color: var(--color-primary);
        color: #fff;
    }

    .breadcrumbs .page-header {
        padding: 0;
    }

    .breadcrumbs .page-header h1 {
        font-size: 56px;
        font-weight: 500;
        color: #fff;
        font-family: var(--font-primary);
    }

    /* Breadcrumb Navigation için stiller */
    .breadcrumb-nav {
        padding: 20px 0;
        background: #f6f6f6;
    }

    .breadcrumb-nav ol {
        display: flex;
        flex-wrap: wrap;
        list-style: none;
        margin: 0;
        padding: 0;
        font-size: 16px;
    }

    .breadcrumb-nav ol li {
        display: flex;
        align-items: center;
    }

    .breadcrumb-nav ol li + li {
        padding-left: 10px;
    }

    .breadcrumb-nav ol li + li::before {
        display: inline-block;
        padding-right: 10px;
        color: #6c757d;
        content: "/";
    }

    .breadcrumb-nav ol li a {
        color: #6c757d;
        text-decoration: none;
        transition: 0.3s;
    }

    .breadcrumb-nav ol li a:hover {
        color: var(--color-primary);
    }

    .breadcrumb-nav ol li:last-child {
        color: #999;
    }

    /* İçerik için padding */
    .blog {
        padding: 40px 0;
    }

    /* Ana makale görseli için stiller */
    .post-img {
        margin-bottom: 20px;
        text-align: center;
        border-radius: 8px;
        overflow: hidden;
    }

    .post-img img {
        max-width: 100%;
        height: auto;
        display: block;
        margin: 0 auto;
    }

    /* Makale içeriğindeki görseller için stiller */
    .blog-details .content img {
        max-width: 100%;
        height: auto;
        margin: 15px auto;
        display: block;
        border-radius: 4px;
    }

    .blog-details .content figure {
        margin: 15px 0;
        padding: 0;
        max-width: 100%;
    }

    /* Yorum bölümü için stiller */
    .comments-section {
        margin-top: 2rem;
        padding-top: 2rem;
        border-top: 1px solid #eee;
    }

    .comment {
        background-color: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1rem;
    }

    .comment:last-child {
        border-bottom: none !important;
    }

    .comment strong {
        color: var(--color-primary);
    }

    .comment small {
        font-size: 0.85rem;
    }

    .comment p {
        margin-top: 0.5rem;
        color: #333;
    }

    /* Responsive düzenlemeler */
    @media (max-width: 768px) {
        .breadcrumbs {
            padding: 120px 0 40px 0;
        }

        .breadcrumbs .page-header h1 {
            font-size: 36px;
        }
    }
</style>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\politikaatlasi\resources\views/articles/show.blade.php ENDPATH**/ ?>