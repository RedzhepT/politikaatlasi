<?php $__env->startSection('content'); ?>
<section id="contact" class="contact">
    <div class="container" data-aos="fade-up">
        <div class="section-header">
            <h2>İletişim</h2>
            <p>Bizimle iletişime geçmek için aşağıdaki formu kullanabilirsiniz.</p>
        </div>

        <div class="row gx-lg-0 gy-4">
            <div class="col-lg-8 mx-auto">
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('contact.send')); ?>" method="post" role="form" class="php-email-form">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <input type="text" name="name" class="form-control" id="name" 
                                placeholder="Adınız" required value="<?php echo e(old('name')); ?>">
                        </div>
                        <div class="col-md-6 form-group mt-3 mt-md-0">
                            <input type="email" class="form-control" name="email" id="email" 
                                placeholder="E-posta Adresiniz" required value="<?php echo e(old('email')); ?>">
                        </div>
                    </div>
                    <div class="form-group mt-3">
                        <input type="text" class="form-control" name="subject" id="subject" 
                            placeholder="Konu" required value="<?php echo e(old('subject')); ?>">
                    </div>
                    <div class="form-group mt-3">
                        <textarea class="form-control" name="message" rows="7" 
                            placeholder="Mesajınız" required><?php echo e(old('message')); ?></textarea>
                    </div>
                    <div class="text-center"><button type="submit">Mesaj Gönder</button></div>
                </form>
            </div>
        </div>
    </div>
</section>

<style>
.alert {
    margin-bottom: 20px;
}

.alert ul {
    list-style: none;
    padding-left: 0;
}

.php-email-form .error-message {
    display: none;
    color: #fff;
    background: #df1529;
    text-align: left;
    padding: 15px;
    margin-bottom: 24px;
    font-weight: 600;
}

.php-email-form .sent-message {
    display: none;
    color: #fff;
    background: #059652;
    text-align: center;
    padding: 15px;
    margin-bottom: 24px;
    font-weight: 600;
}

.php-email-form button[type=submit] {
    background: var(--color-primary);
    border: 0;
    padding: 12px 40px;
    color: #fff;
    transition: 0.4s;
    border-radius: 50px;
}

.php-email-form button[type=submit]:hover {
    background: var(--color-secondary);
}
</style>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\politikaatlasi\resources\views/pages/contact.blade.php ENDPATH**/ ?>