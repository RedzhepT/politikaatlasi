<?php $__env->startSection('content'); ?>
<div class="breadcrumbs">
    <div class="page-header d-flex align-items-center">
        <div class="container position-relative">
            <div class="row d-flex justify-content-center">
                <div class="col-lg-6 text-center">
                    <h1>Blog</h1>
                    <p>Siyasi analizler ve değerlendirmeler</p>
                </div>
            </div>
        </div>
    </div>
    <nav>
        <div class="container">
            <ol>
                <li><a href="<?php echo e(route('home')); ?>">Anasayfa</a></li>
                <li>Blog</li>
            </ol>
        </div>
    </nav>
</div>

<section id="blog" class="blog">
    <div class="container" data-aos="fade-up">
        <div class="row gy-4 posts-list">
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-4 col-md-6">
                <article class="blog-post">
                    <div class="post-img">
                        <img src="<?php echo e(asset($article->image)); ?>" alt="" class="img-fluid">
                    </div>
                    <?php if($article->category): ?>
                        <p class="post-category"><?php echo e($article->category->name); ?></p>
                    <?php endif; ?>
                    <h2 class="title">
                        <a href="<?php echo e(route('articles.show', $article->slug)); ?>"><?php echo e($article->title); ?></a>
                    </h2>
                    <div class="d-flex align-items-center">
                        <img src="<?php echo e(asset($article->author_image)); ?>" alt="" class="img-fluid post-author-img flex-shrink-0">
                        <div class="post-meta">
                            <p class="post-author"><?php echo e($article->author_name); ?></p>
                            <p class="post-date">
                                <time datetime="<?php echo e($article->created_at); ?>"><?php echo e($article->created_at->format('d M Y')); ?></time>
                            </p>
                        </div>
                    </div>
                </article>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="blog-pagination">
            <?php echo e($articles->links()); ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\LARAVEL\politikaatlasi\resources\views/articles/index.blade.php ENDPATH**/ ?>