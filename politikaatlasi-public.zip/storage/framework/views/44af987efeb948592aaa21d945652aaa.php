<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['paginator']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['paginator']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php if($paginator->hasPages()): ?>
<div class="admin-pagination">
    <div class="pagination-wrapper">
        <div class="pagination-nav">
            
            <?php if($paginator->onFirstPage()): ?>
                <span class="page-button disabled">
                    <i class="bi bi-chevron-left"></i>
                </span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="page-button">
                    <i class="bi bi-chevron-left"></i>
                </a>
            <?php endif; ?>

            
            <?php
                $start = max($paginator->currentPage() - 2, 1);
                $end = min($paginator->currentPage() + 2, $paginator->lastPage());
            ?>

            <?php if($start > 1): ?>
                <a href="<?php echo e($paginator->url(1)); ?>" class="page-button">1</a>
                <?php if($start > 2): ?>
                    <span class="page-button disabled">...</span>
                <?php endif; ?>
            <?php endif; ?>

            <?php for($i = $start; $i <= $end; $i++): ?>
                <?php if($i == $paginator->currentPage()): ?>
                    <span class="page-button active"><?php echo e($i); ?></span>
                <?php else: ?>
                    <a href="<?php echo e($paginator->url($i)); ?>" class="page-button"><?php echo e($i); ?></a>
                <?php endif; ?>
            <?php endfor; ?>

            <?php if($end < $paginator->lastPage()): ?>
                <?php if($end < $paginator->lastPage() - 1): ?>
                    <span class="page-button disabled">...</span>
                <?php endif; ?>
                <a href="<?php echo e($paginator->url($paginator->lastPage())); ?>" class="page-button"><?php echo e($paginator->lastPage()); ?></a>
            <?php endif; ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="page-button">
                    <i class="bi bi-chevron-right"></i>
                </a>
            <?php else: ?>
                <span class="page-button disabled">
                    <i class="bi bi-chevron-right"></i>
                </span>
            <?php endif; ?>
        </div>
        <div class="page-info">
            <?php echo e($paginator->firstItem()); ?>-<?php echo e($paginator->lastItem()); ?> / <?php echo e($paginator->total()); ?>

        </div>
    </div>
</div>
<?php endif; ?> <?php /**PATH C:\LARAVEL\politikaatlasi\resources\views/components/admin-pagination.blade.php ENDPATH**/ ?>