<header id="header" class="header d-flex align-items-center">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">
        <a href="<?php echo e(route('home')); ?>" class="logo d-flex align-items-center">
            <h1>Politika Atlası</h1>
        </a>
        
        <nav id="navbar" class="navbar">
            <ul>
                <li><a href="<?php echo e(route('home')); ?>">Anasayfa</a></li>
                <li><a href="<?php echo e(route('about')); ?>">Hakkımızda</a></li>
                <li><a href="<?php echo e(route('articles.index')); ?>">Blog</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">İletişim</a></li>
                <li>
                    <a href="#" data-bs-toggle="modal" data-bs-target="#searchModal">
                        <i class="bi bi-search"></i>
                    </a>
                </li>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->is_admin): ?>
                        <li><a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-admin">
                            <i class="bi bi-speedometer2"></i> Admin Panel
                        </a></li>
                    <?php endif; ?>
                    <li class="nav-item dropdown d-lg-none">
                        <a href="#" class="nav-link mobile-dropdown-toggle">
                            <i class="bi bi-person-circle"></i> <?php echo e(auth()->user()->name); ?>

                        </a>
                        <ul class="mobile-dropdown-menu">
                            <li><a class="dropdown-item" href="#">
                                <i class="bi bi-person"></i> Profil
                            </a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="<?php echo e(route('logout')); ?>" method="POST" class="px-0">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item text-danger">
                                        <i class="bi bi-box-arrow-right"></i> Çıkış Yap
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="d-lg-none">
                        <a href="<?php echo e(route('login')); ?>">
                            <i class="bi bi-box-arrow-in-right"></i> Giriş Yap
                        </a>
                    </li>
                    <li class="d-lg-none">
                        <a href="<?php echo e(route('register')); ?>">
                            <i class="bi bi-person-plus"></i> Kayıt Ol
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>

        <?php if(auth()->guard()->check()): ?>
            <div class="user-menu d-none d-lg-block">
                <div class="dropdown">
                    <a href="#" class="nav-link dropdown-toggle text-white" 
                            type="button" 
                            id="userDropdownBtn"
                            data-bs-toggle="dropdown" 
                            aria-expanded="false">
                        <i class="bi bi-person-circle"></i> 
                        <?php echo e(auth()->user()->name); ?>

                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdownBtn">
                        <li>
                            <a class="dropdown-item" href="#">
                                <i class="bi bi-person"></i> Profil
                            </a>
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form action="<?php echo e(route('logout')); ?>" method="POST" class="px-0">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="dropdown-item text-danger">
                                    <i class="bi bi-box-arrow-right"></i> Çıkış Yap
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        <?php else: ?>
            <div class="auth-buttons d-none d-lg-flex gap-2">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-box-arrow-in-right"></i> Giriş Yap
                </a>
                <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-person-plus"></i> Kayıt Ol
                </a>
            </div>
        <?php endif; ?>

        <i class="mobile-nav-toggle mobile-nav-show bi bi-list"></i>
        <i class="mobile-nav-toggle mobile-nav-hide d-none bi bi-x"></i>
    </div>
</header>

<?php echo $__env->make('layouts.partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <?php /**PATH C:\LARAVEL\politikaatlasi\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>