import "./bootstrap";

// Çıkış yapma formunu otomatik olarak submit eden fonksiyonu kaldırıyorum
// çünkü artık bu işlemi HTML tarafında onclick ile yapıyoruz
